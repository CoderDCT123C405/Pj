public interface iQUANLY {
    public void them();
    public void capNhat(String id);
    public void xoa(String id);
    public void timKiem(String id);
    public void hienThi();
    public void SX_Soluong();
    public void SX_Ten();
}
