import java.util.Scanner;
class NHANVIEN extends NGUOI {
    private String idnv;
    private int SL_Ban,luong;
    Scanner inp = new Scanner(System.in);
    public NHANVIEN(){
        super();
        idnv="";
        SL_Ban=0;
        luong=0;
    }
    public NHANVIEN(String cccd, String ten, String sdt, String diaChi, int namSinh, int thuong, String idnv, int SL_Ban,int luong){
        super(cccd, ten, sdt, diaChi, namSinh,thuong);
        this.idnv=idnv;
        this.SL_Ban=SL_Ban;
        this.luong=luong;
    }
    void setIdnv(String idnv){
        this.idnv=idnv;
    }
    String getIdnv(){
        return idnv;
    }
    public void setSL_Ban(int SL_Ban) {
        this.SL_Ban = SL_Ban;
    }
    public int getSL_Ban() {
        return SL_Ban;
    }
    public void nhap(boolean coIdnv){
        super.nhap();
        if (!coIdnv){
            System.out.printf("Id nhan vien: ");
            idnv=inp.nextLine();
        }
    }
    public int getLuong() {
        return luong;
    }
    public void setLuong(int luong) {
        this.luong = luong;
    }
    @Override public void xuat(){
        super.xuat();
        int width=-10;
        System.out.printf("\n%"+width+"s: %"+width+"s\n","Idnv",idnv);
    }
    @Override public int tinhThuong(){
         int temp=0,soluong=20,tempSlban=SL_Ban;
         while (tempSlban>0){
             if (tempSlban>soluong){
                 temp+=luong/10;
             }
             tempSlban-=soluong;
         }
         return temp;
    }
}
