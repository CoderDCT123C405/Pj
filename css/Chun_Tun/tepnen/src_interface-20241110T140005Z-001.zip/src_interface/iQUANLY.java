public interface iQUANLY{
    void them();
    void capNhat(String string);
    void xoa(String string);
    void timKiem(String string);
    void hienThi();
    void SX_Soluong();
    void SX_Ten();
}
