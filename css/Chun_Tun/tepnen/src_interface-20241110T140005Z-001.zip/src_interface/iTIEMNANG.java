public interface iTIEMNANG {
    void XUAT();
}
