public interface iQuanLy {
    public void Them();
    public void CapNhat();
    public void Tim();
    public void HienThi();
}
