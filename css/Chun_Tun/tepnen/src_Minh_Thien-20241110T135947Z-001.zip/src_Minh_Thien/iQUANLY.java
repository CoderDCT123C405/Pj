/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */

/**
 *
 * @author DELL
 */
public interface iQUANLY {
    public void them();
    public void capNhat(String id);
    public void xoa(String id);
    public void timKiem(String id);
    public void hienThi();
}
